# Silly Mouse script
Why? Because why not? This is the ultimate troll that messes with your victim's mouse settings to unbearable levels.
Inspired by Caleb Hutchinson's Silly Mouse Ducky Payload from hak5darren/USB-Rubber-Ducky, ported to Windows 10 and made better.

# This script does the following:
1. Opens Mouse Properties
2. Switches primary and secondary buttons
3. Changes double-click speed to slow
4. Displays pointer trails
5. Decreases pointer speed to lowest possible setting
6. Increases Vertical Scroll increment to 100 lines

# Credits
- Vel1khaN